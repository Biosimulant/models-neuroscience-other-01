

import custom_params
custom_params.filename = 'g37e1i002'
from common import rank
import bindict
import params
bindict.mknetwork([37])
bindict.save('g37.dic')

